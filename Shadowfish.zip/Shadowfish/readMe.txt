You'll need to copy all of the files in the ShadowFish folder into the folder containing the recordings you want to process. You will also need a recording of the empty tank titled Background.mp4 for background extraction.

Open command prompt and direct to the folder containing ShadowFish.exe, the recordings you want to process and the remaining ShadowFish files.
e.g. cd C:/...

Then type out:

ShadowFish.exe -i "input video name".mp4 -r 0 3000 -b Background.mp4 -f 100 -o "input video name".csv --saveOutput "input video name".tracked.avi

(replacing "input video name" with the name of the recording you want to process)
(you can also change the range of frames processed, the first number after -r is the starting frame and the second number is the final frame processed. Recordings are 100fps)

Alternatively you can use BatchProcess. To process all the recordings in a folder instead of doing each separately. You'll want to edit the BatchProcess code to direct command prompt to the right folder and select the range of frames you want to process.